package CCSL_TSQL_Day3_Library;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MyLib1 {
	ChromeDriver wd;
	
	// initialization for driver instance
	public void init(ChromeDriver wd) {
		this.wd=wd;
		
	}
	// method 1
	public void Perform_DragDrop() {
		wd.get("https://jqueryui.com/droppable/");
		wd.switchTo().frame(0);
		String src = "//*[@id='draggable']";
				
		String dest = "//*[@id='droppable']";
		
		Actions act = new Actions(wd);
		
		act.clickAndHold(wd.findElement(By.xpath(src))).moveToElement(wd.findElement(By.xpath(dest))).build().perform();

	}
	 
	 // method 2
	 
	public void Extract_Data_From_WebTable() throws InterruptedException {
		 wd.get("https://www.w3schools.com/html/html_tables.asp");
			Thread.sleep(2000);
			String lxp , rxp , mxp;
			
			lxp="/html/body/div[5]/div[1]/div[1]/div[3]/div/table/tbody/tr[";
			rxp = "]/td[1]";
			System.out.println("***********Company column **************");

			
			for(int i=2;i<=5;i++) {
				WebElement el = wd.findElement(By.xpath(lxp+ i + rxp));
				
				String s = el.getText();
//				System.out.println("***********Company column **************");
				System.out.println(s);
				Thread.sleep(1000);
				
			}
			

	 }

}
