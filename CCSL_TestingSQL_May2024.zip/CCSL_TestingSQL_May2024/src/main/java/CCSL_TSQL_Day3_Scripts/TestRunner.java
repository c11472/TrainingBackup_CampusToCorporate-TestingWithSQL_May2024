package CCSL_TSQL_Day3_Scripts;

import org.openqa.selenium.chrome.ChromeDriver;

import CCSL_TSQL_Day3_Library.MyLib1;

public class TestRunner {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		ChromeDriver wd = new ChromeDriver();
		
		// lib class object
		
		MyLib1 testobj1 = new MyLib1();
		
		// call the methods
		
		testobj1.init(wd);
		// drag & drop
		testobj1.Perform_DragDrop();
		
		// webtable
		
		testobj1.Extract_Data_From_WebTable();
		
		
		

	}

}
