package CCSL_TSQL_Day3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ObjectReposdemo1 {

	public static void main(String[] args) throws IOException {
		Properties p;
    	FileReader f;
		WebDriver wd = new ChromeDriver();
		p = new Properties();
		f= new FileReader("./TestData_Login_DDT_TC001/or1_login.properties");
		// launch login page of rediffmail
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
		
		p.load(f);
		
		// WebElements 
		
		WebElement username = wd.findElement(By.xpath(p.getProperty("username1")));
		
		
        if(username != null)		{
        	System.out.println("Locator successfully captured from perperties file");
        }
        else {
        	System.out.println("-----Exception -----");
        }
		

	}


	}

