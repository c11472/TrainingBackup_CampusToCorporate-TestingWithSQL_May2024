package CCSL_TSQL_Day3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ReadDataFromProperties {

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		
		System.out.println("Read the data from properties file");
		// FileReader 
		
		FileReader  fr =
				new FileReader("./TestData_Login_DDT_TC001/or1_login.properties");
		// Properties instance
		
		Properties p = new Properties();
		//load
		p.load(fr);
		String nameval= (String) p.get("name");
		String email1= (String) p.get("email");

		
		System.out.println(nameval);
		
		Thread.sleep(2000);
		
		System.out.println(email1);	
        
	}

}
