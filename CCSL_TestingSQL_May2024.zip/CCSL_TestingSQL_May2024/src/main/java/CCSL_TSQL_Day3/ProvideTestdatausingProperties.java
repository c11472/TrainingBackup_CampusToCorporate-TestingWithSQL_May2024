package CCSL_TSQL_Day3;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class ProvideTestdatausingProperties {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		Properties p1;
		Properties p2;
    	FileReader f1;
    	FileReader f2;
		WebDriver wd = new FirefoxDriver();
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi"); // external file

		p1 = new Properties();
		f1= new FileReader("./TestData_Login_DDT_TC001/or1_login.properties");
		p2= new Properties();
		f2=new FileReader("./TestData_Login_DDT_TC001/testdata.properties");
		// launch login page of rediffmail
		//wd.manage().window().maximize();
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
		
		p1.load(f1);
		p2.load(f2);
		
		// WebElements 
		if(wd.findElement(By.xpath(p1.getProperty("username1"))).isDisplayed()){
			wd.findElement(By.xpath(p1.getProperty("username1"))).clear();
			wd.findElement(By.xpath(p1.getProperty("username1")))
			.sendKeys(p2.getProperty("usinp1"));
		}
		else {
			System.out.println("Username is not present");
			
		}
		Thread.sleep(2000);
		if(wd.findElement(By.xpath(p1.getProperty("password1"))).isDisplayed()) {
			wd.findElement(By.xpath(p1.getProperty("password1"))).clear();
			wd.findElement(By.xpath(p1.getProperty("password1")))
			.sendKeys(p2.getProperty("usinp2"));
		}
		else {
			System.out.println("Password is not present");
			
		}
		Thread.sleep(2000);
        if(wd.findElement(By.xpath(p1.getProperty("signin1"))).isDisplayed()) {
        	wd.findElement(By.xpath(p1.getProperty("signin1"))).click();
        }
        else {
        	System.out.println("button is not present");
        	
        }
        
        Thread.sleep(2000);
		wd.close();
		
		
		
      /*  String uinp1 = p1.getProperty("usinp1");
        String uinp2 = p1.getProperty("usinp2");
        
        signinbutton.click();
        
        System.out.println("User name is: " + " "+ uinp1);
        System.out.println("Password is : "+ " "+ uinp2);
        
        // pass the testdata
        username.clear();
        username.sendKeys(p1.getProperty("usinp1")); 
        password.clear();
        password.sendKeys(p1.getProperty("usinp2")); 
        // click on login
        signinbutton.click();*/
	}

}
