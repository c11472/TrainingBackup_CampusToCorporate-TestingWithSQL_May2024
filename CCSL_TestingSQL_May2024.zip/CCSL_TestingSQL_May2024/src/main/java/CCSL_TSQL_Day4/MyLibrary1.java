package CCSL_TSQL_Day4;

public class MyLibrary1 {

}
