package CCSL_TSQL_Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragDropDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChromeDriver wd = new ChromeDriver();
		
		wd.get("https://jqueryui.com/droppable/");
		wd.switchTo().frame(0);
		String src = "//*[@id='draggable']";
				
		String dest = "//*[@id='droppable']";
		
		Actions act = new Actions(wd);
		
		act.clickAndHold(wd.findElement(By.xpath(src))).moveToElement(wd.findElement(By.xpath(dest))).build().perform();

	}

}
