package CCSL_TSQL_Day4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebTableDataExtractDemo {

	public static void main(String[] args) throws InterruptedException  {
		// TODO Auto-generated method stub
		ChromeDriver wd = new ChromeDriver();
		
		wd.get("https://www.w3schools.com/html/html_tables.asp");
		Thread.sleep(2000);
		String lxp , rxp , mxp;
		
		lxp="/html/body/div[5]/div[1]/div[1]/div[3]/div/table/tbody/tr[";
		rxp = "]/td[1]";
		System.out.println("***********Company column **************");

		
		for(int i=2;i<=5;i++) {
			WebElement el = wd.findElement(By.xpath(lxp+ i + rxp));
			
			String s = el.getText();
//			System.out.println("***********Company column **************");
			System.out.println(s);
			Thread.sleep(1000);
			
		}
		
		
		
		
		

	}

}
