package CCSL_TestingSQL_May2024.CCSL_TestingSQL_May2024;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_DDT_TC001 {
    static WebDriver wd;  
    // Properties instance
    
    static void main(String[] args) throws IOException {
    	
    	//properties instance
    	Properties p;
    	FileReader f;
		// TODO Auto-generated method stub
		wd = new ChromeDriver();
		p = new Properties();
		f= new FileReader("./TestData_Login_DDT_TC001/or1_login.properties");
		// launch login page of rediffmail
		wd.get("https://mail.rediff.com/cgi-bin/login.cgi");
		
		p.load(f);
		
		// WebElements 
		
		WebElement username = wd.findElement(By.xpath(p.getProperty("username1")));
		username.sendKeys("gayatri mishra");
		//WebElement password = wd.findElement(By.xpath(""));
		
		//WebElement signin = wd.findElement(By.xpath(""));
		
		

	}

}
