package CCSL_TSQL_Day4_TestNGWithSeleniumDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class automationExercise_TestScript_01 {
  WebDriver wd ;//= new FirefoxDriver();
  WebElement unm ;//= wd.findElement(By.xpath("//*[@id=\\\"form\\\"]/div/div/div[1]/div/form/input[2]"));
  //WebElement pwd = By.xpath("");
  //WebElement button = By.xpath("");
  @BeforeTest
  public void Invoke_App() throws InterruptedException {
	   wd = new FirefoxDriver();
	 	 // wd.get("https://automationexercise.com/login");
  }
  
  @Test
  public void test2() {
 	  wd.get("https://automationexercise.com/login");
 	  unm=wd.findElement(By.xpath("/html/body/section/div/div/div[1]/div/form/input[2]"));
 	  unm.sendKeys("gayatri");
  }
  
  
 /* @Test(priority=2)
  public void Login_App() throws InterruptedException {
	  
	  if(unm.isDisplayed()) {
		  unm.clear();
		  unm.sendKeys("gayatri");
	  }
	  else {
		  System.out.println("Invalid element ");
	  }
  }*/
  
  
}
