package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import org.openqa.selenium.WebDriver;

public class TestNG_AnnotationsDemo_Lib_Utility  implements BaseInterface{
	// main method
	static TestNG_AnnotationsDemo_Lib_Utility t1;
	public static void main(String args[]) {
		
	 try {
		t1 = new TestNG_AnnotationsDemo_Lib_Utility();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
				
	// Blank	
	}
	
WebDriver wd;

// init method
public void init_utility(WebDriver wd) {
	this.wd = wd;
	
}
	
// method for exception-Thread
public void	Exception1(){
	 try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

public void call4interface() {
	t1.testmethod();
}


public void testmethod() {
	System.out.println("This is a design pattern which can be used in framework");
	
	
}

}
