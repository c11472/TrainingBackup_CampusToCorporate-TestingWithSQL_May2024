package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

public interface BaseInterface {
	
  
 abstract void testmethod();

}
