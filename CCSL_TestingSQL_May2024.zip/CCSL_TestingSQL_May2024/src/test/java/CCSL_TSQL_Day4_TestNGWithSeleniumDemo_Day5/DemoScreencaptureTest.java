package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.google.common.io.Files;

public class DemoScreencaptureTest {
  WebDriver driver;
  @Test
  public void SearchStringGoogleValidate() throws IOException, InterruptedException {
	  driver = new ChromeDriver();
	  driver.get("https://www.yahoo.com/");
	  Thread.sleep(4000);
	  WebElement inp = driver.findElement(By.xpath("//*[@id='ybar-sbq']"));
	  
	  if(inp.isDisplayed()) {
		  inp.sendKeys("Test data from auytomation");
	  }
	  else {
		  System.out.println("Invalid locator");
	  }
	  
	  
	  
	  // capture the screen image
	  File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	  Files.copy(src, new File("./Screenshots/testimage1.png"));

  }
}
