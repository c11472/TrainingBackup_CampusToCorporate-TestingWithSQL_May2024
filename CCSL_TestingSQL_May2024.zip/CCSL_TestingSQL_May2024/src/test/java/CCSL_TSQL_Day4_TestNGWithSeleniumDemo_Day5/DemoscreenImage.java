package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class DemoscreenImage {
	WebDriver wd;
	
	TestNG_AnnotationsDemo_Lib_Steps objtest = new TestNG_AnnotationsDemo_Lib_Steps();
  @Test
  public void f() throws IOException {
	  wd = new FirefoxDriver();
	  objtest.inittestdriver(wd);
	  objtest.invokeapp(); // file --- screenshots
  }
}
