package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class TestNG_AnnotationsDemo {
  WebDriver wd;
  //Object for the TestNG_AnnotationsDemo_Lib_Utility
  TestNG_AnnotationsDemo_Lib_Utility  obj1 = new TestNG_AnnotationsDemo_Lib_Utility ();
//  TestNG_AnnotationsDemo objtest2= new TestNG_AnnotationsDemo();
  
  //ExtentReports var
  ExtentReports ext1; // class 
  ExtentTest test;//interface

  @BeforeTest
  public void setup_method() {
	  System.out.println("Pre conditions :");
	   wd = new ChromeDriver();
	   wd.manage().window().maximize();
	   wd.manage().deleteAllCookies();
	   //ExtentReports config
	   ExtentHtmlReporter testreport = new ExtentHtmlReporter(".//SampleReports//finalreport.html"); // path
		  ext1=new ExtentReports(); // object
		  ext1.attachReporter(testreport);
		  test = ext1.createTest("user.dir", "test");
	  
  }
  @Test(priority=1)
  public void LaunchAppLoginPage() {
	  
	  obj1.init_utility(wd);
	  wd.get("https://automationexercise.com/login");
	  System.out.println("login page opened :");
	 
	  obj1.Exception1();
	  test.log(Status.PASS, "the app is invoked successfully");
	  
	  
	
	  
  }
  
  @Test(priority=2)
  public void GetPageTitle(){
	  String HomePageTitle = wd.getTitle();
	  System.out.println(HomePageTitle + " " + HomePageTitle);
	  obj1.Exception1();
	  
	  test.log(Status.PASS, "The title of the HomePage extracted");
	
	  
  }
  
  @Test(priority=3)
  public void ExtractTextFromLoginPage() {
	  WebElement logintext = wd.findElement(By.xpath("//h2[contains(text(),'Login to your account')]"));
	  String textext1 = logintext.getText();
	  System.out.println("Text extracted for validation from login page:" + "  "+textext1);
	  obj1.Exception1();
	  
	  test.log(Status.PASS, "Login page validated");
	  
	  

  }
  @Test(priority=4)
  public void CloseTheApp()  {
	  wd.close();
	  System.out.println("Application closed");
	  obj1.Exception1();
	  obj1.testmethod(); // interface
	  
	  test.log(Status.PASS, "App closed successfully");

	  
  }
  
  @AfterTest
  public void teardown_method() {
	  System.out.println("post conditions:");
	  ext1.close();
	  ext1.flush();
	  
  }

}
