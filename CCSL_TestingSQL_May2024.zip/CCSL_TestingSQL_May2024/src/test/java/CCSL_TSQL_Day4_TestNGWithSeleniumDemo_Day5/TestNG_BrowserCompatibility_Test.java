package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNG_BrowserCompatibility_Test {
  WebDriver wd;
  //create object for lib
  TestNG_AnnotationsDemo_Lib_Steps obttest1n= new TestNG_AnnotationsDemo_Lib_Steps();
  @Test
  public void TestWithFirefox() {
	  wd = new FirefoxDriver();
	  obttest1n.inittestdriver(wd);
	  obttest1n.invokeapp();
	  
	 	  
  }
  
  @Test
  public void TestWithChrome() {
	  WebDriver wd = new ChromeDriver();
	  obttest1n.inittestdriver(wd);
	  obttest1n.invokeapp();
	  
  }
  
 
}
