package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.google.common.io.Files;

public class TestNG_AnnotationsDemo_Lib_Steps {
	WebDriver wd;
	
	public void inittestdriver(WebDriver wd) {
		this.wd = wd;
	}
	
	public void invokeapp() throws IOException {
		wd.get("https://www.amazon.in/");
		String TitleOfThePage = wd.getTitle();
		System.out.println("The title is :" + " " + TitleOfThePage);
		
		// Take a screenshot
		File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("./Screenshots/amazonlaunchapp.png"));

		
	}
	
	
	

}
