package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import org.testng.annotations.Test;

public class TestNG_AnnotationsDemo1 {
	TestNG_AnnotationsDemo_Lib_Utility  obj2 = new TestNG_AnnotationsDemo_Lib_Utility ();
  @Test
  public void f() {
	  obj2.testmethod();
  }
}
