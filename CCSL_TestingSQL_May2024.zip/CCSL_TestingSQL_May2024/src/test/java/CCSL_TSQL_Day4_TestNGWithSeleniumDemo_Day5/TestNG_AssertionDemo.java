package CCSL_TSQL_Day4_TestNGWithSeleniumDemo_Day5;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class TestNG_AssertionDemo {
  WebDriver wd = new ChromeDriver();
  @Test
  public void f() throws IOException {
	  wd.get("https://www.amazon.in/");
	  FileReader fr = new FileReader("./TestData_Login_DDT_TC001/cheskdata.properties");
	  Properties p1 = new Properties();
	  p1.load(fr);
	  String expval = p1.getProperty("pgtitle");
	  String PageTitleAmazonHome = wd.getTitle();
	//  Assert.assertEquals(PageTitleAmazonHome,expval);
	  Assert.assertEquals(PageTitleAmazonHome, expval, "The assertion result");
	  
	 // Assert.
	  
	  
  }
}
