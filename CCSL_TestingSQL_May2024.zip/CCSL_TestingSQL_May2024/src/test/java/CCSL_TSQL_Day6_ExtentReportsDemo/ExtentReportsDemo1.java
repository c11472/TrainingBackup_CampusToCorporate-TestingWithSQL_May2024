package CCSL_TSQL_Day6_ExtentReportsDemo;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class ExtentReportsDemo1 {
	
  WebDriver wd ;
  ExtentReports ext1; // class 
  ExtentTest test;//interface
  int x,y,sum ,p,q,sub,prod,div;

  @BeforeTest
  public void setup() {
	  ExtentHtmlReporter testreport = new ExtentHtmlReporter(".//TestReports//deliverablesdata.html"); // path
	  ext1=new ExtentReports(); // object
	  ext1.attachReporter(testreport);
	  test = ext1.createTest("user.dir", "test");
	 

	  
	  
  }
  @Test
  public void Calc_Addition() {
	  
	  x=20;
	  y=10;
	  sum=x+y;
	  if(sum>=30) {
	  // perform automation step-1
	  test.log(Status.PASS, "The step-1 is passed");
	  }
	  else {
		  test.log(Status.FAIL, "The step-1 is failed"); //

		  
	  }
	  
  }
  
  @Test
  public void Calc_Subtraction() {
	  p=100;
	  q=10;
	int sub=p-q;
	if(sub<200) {
	test.log(Status.PASS, "The step-2 is passes");
	}
	else {
		test.log(Status.PASS, "the step-2 is failed");
		
	}
	  
  }
  @AfterTest
  public void teardown() {
	  ext1.close();
	  ext1.flush();
	  
  }
}
