package CCSL_TSQL_Day4_TestNGDemo;

import org.testng.annotations.Test;

public class newSCR1 {
  @Test
  public void f() {
	  System.out.println("New suite demo");
  }
}
