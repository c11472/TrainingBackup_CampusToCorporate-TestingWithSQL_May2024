package CCSL_TSQL_Day4_TestNGDemo;

import org.testng.annotations.Test;

public class Script003 {
  @Test
  public void f() {
  }
}
