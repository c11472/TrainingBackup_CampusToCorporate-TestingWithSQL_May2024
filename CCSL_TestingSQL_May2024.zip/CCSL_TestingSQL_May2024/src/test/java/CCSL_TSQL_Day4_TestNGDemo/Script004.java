package CCSL_TSQL_Day4_TestNGDemo;

import org.testng.annotations.Test;

import io.opentelemetry.exporter.logging.SystemOutLogRecordExporter;

public class Script004 {
  @Test
  public void f() {
	  System.out.println("Regression suite demo");
    }
}
