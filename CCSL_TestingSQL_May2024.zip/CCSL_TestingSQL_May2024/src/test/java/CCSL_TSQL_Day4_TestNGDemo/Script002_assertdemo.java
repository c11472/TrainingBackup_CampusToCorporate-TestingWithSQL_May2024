package CCSL_TSQL_Day4_TestNGDemo;

import org.testng.annotations.Test;

public class Script002_assertdemo {
  @Test
  public void f() {
	  System.out.println("Hello world !" + "Regression demo");
  }
}
