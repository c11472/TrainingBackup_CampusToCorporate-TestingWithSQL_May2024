package CCSL_TSQL_Day4_TestNGDemo;

import org.testng.annotations.Test;

public class Script001 {
  @Test(priority=1)
  public void testmethod1() {
	  System.out.println("hello , this is the first annotation in testNG");
  }
  
  @Test(priority=5)
  public void testmethod2() {
	  System.out.println("hello , this is the second annotation in testNG");

	  
  }
  
  @Test(priority=3)
  public void testmethod3() {
	  System.out.println("hello , this is the third annotation in testNG");

	  
  }
  
  @Test(priority=4)
  public void testmethod4() {
	  System.out.println("hello , this is the fourth annotation in testNG");
  }
  
  @Test(priority=6)
  public void testmethod5() {
	  System.out.println("hello , this is the 5th annotation in testNG");
  }
  @Test(priority=2)
  public void testmethod6() {
	  System.out.println("hello , this is the 6th annotation in testNG");
  }




}
