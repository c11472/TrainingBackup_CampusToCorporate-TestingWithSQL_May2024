package com.Page1_Home.automationexercise;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.google.common.io.Files;


public class TC001_HomePage_Lib1 {
	WebDriver wd;
	
	 // Locators
	By validtextcheck = By.xpath("//*[contains(text( ),'Signup / Login')]");
	
	By validateProducts = By.xpath("//*[contains(text(),' Products')]");
	
	// Properties file
	Properties P1 = new Properties();
	FileReader file2;
	
	
	// driver init method
	 public  void init1(WebDriver wd) {
		this.wd = wd;
		
	}
	 // automation scripts for steps in method
	
	public  void launchapp() throws IOException {
		file2 = new FileReader("./InputData/config.properties");
		P1.load(file2);
		//wd.get("https://automationexercise.com/");
		wd.get(P1.getProperty("baseurl"));
		
	}
	
	public void validate_homepage() {
		
		if(wd.findElement(validtextcheck).isDisplayed()){
			System.out.println("App invoked");
			
		}
		else {
			System.out.println("Locator invalid");
		}
		
	}
	
	
	public void validate_productsopt() {
		if(wd.findElement(validateProducts).isDisplayed()) {
			System.out.println("Products is present");
		}
		else {
			System.out.println("invalid component");
		}
	}
	// add one method
	public void clicksignup() throws IOException {
		if(wd.findElement(validtextcheck).isDisplayed()) {
			wd.findElement(validtextcheck).click();
			File src = ((TakesScreenshot) wd).getScreenshotAs(OutputType.FILE);
			Files.copy(src, new File("./Screenshots/signupclicktest.png"));

			
		}
	}
	
	
}
