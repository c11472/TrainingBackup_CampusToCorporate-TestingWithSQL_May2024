package com.Page2_Login.automationexercise;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TC002_LoginPage_Lib2 {
	WebDriver wd;
	
	//Locators
	By unm=By.xpath("(//*[@name='email'])[1]");
	By pwd = By.xpath("//*[@name='password']");
	
	By lgin = By.xpath("(//*[contains(text(),'Login')])[4]");
	
	// Access file
	Properties P = new Properties();
	FileReader file1;// = new FileReader("./InputData/inputvalues.properties");
	
	
	// init method
	
	public void init_page2(WebDriver wd) {
		this.wd = wd;
		
	}
	
	//Enter email
	
	public void enter_email() throws IOException {
		file1 = new FileReader("./InputData/inputvalues.properties");
		P.load(file1);
		wd.findElement(unm).sendKeys(P.getProperty("emailid")); //taking data from properties
		
	}
	
	//Enter password
	public void enter_password() {
		wd.findElement(pwd).sendKeys(P.getProperty("pwd"));
	}
	
	//Click on login
	public void click_login() {
	   wd.findElement(lgin).click();
		
	}

}
