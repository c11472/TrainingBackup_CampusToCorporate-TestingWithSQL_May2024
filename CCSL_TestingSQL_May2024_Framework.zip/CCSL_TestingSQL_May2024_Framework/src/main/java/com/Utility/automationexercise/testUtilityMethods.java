package com.Utility.automationexercise;

import org.openqa.selenium.WebDriver;

public class testUtilityMethods {
	WebDriver wd;
	
	
	public void init_utility(WebDriver wd) {
		this.wd = wd;
		
	}
	
	public void Maximize_Browser() {
		wd.manage().window().maximize();
	}
	
	public void wait_time() throws InterruptedException {
		Thread.sleep(2000);
	}
	
	public void navigate_refresh() {
		wd.navigate().refresh();
	}
	
	public void close_browser_instance() {
		wd.close();
		
	}

}
