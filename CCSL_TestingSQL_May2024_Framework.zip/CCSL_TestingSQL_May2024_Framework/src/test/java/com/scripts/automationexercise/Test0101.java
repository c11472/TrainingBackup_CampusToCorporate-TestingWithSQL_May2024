package com.scripts.automationexercise;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.Page1_Home.automationexercise.TC001_HomePage_Lib1;
import com.Page2_Login.automationexercise.TC002_LoginPage_Lib2;
import com.Utility.automationexercise.testUtilityMethods;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class Test0101 {
	//page classes objects
	TC001_HomePage_Lib1 obj = new TC001_HomePage_Lib1();
	
	TC002_LoginPage_Lib2 obj2 = new TC002_LoginPage_Lib2();
	
	testUtilityMethods util1 = new testUtilityMethods();
	
	// Create the instance for browser
	WebDriver wd = new ChromeDriver();
	ExtentReports ext1; // class 
	ExtentTest test;//interface

  @BeforeTest
  public void setupdata() {
	  ExtentHtmlReporter testreport = new ExtentHtmlReporter("./ExtentsHtmlReports/sampleexecutionreport.html"); // path
	  ext1=new ExtentReports(); // object
	  ext1.attachReporter(testreport);
	  test = ext1.createTest("user.dir", "test");

  }

  @Test(priority=1)
  public void function1() throws IOException, InterruptedException {
	  util1.init_utility(wd);
	  util1.Maximize_Browser();
	  //util1.wait();
	  
	  obj.init1(wd);
	  
	  obj.launchapp();
	  test.log(Status.PASS, "the app is launched successfully !");
  }
  @Test(priority=2)
  public void validateHome() {
	  obj.validate_homepage();
	  test.log(Status.PASS, "Home page validated");
  }
  @Test(priority=3)
  public void validate_productsopt1() {
	  obj.validate_productsopt();
	  test.log(Status.PASS, "products validated");
  }
  
  @Test(priority=4)
  public void click_signup_login() throws IOException {
	  obj.clicksignup();
	  test.log(Status.PASS, "clicked");
	  
  }
  
  @Test(priority=5)
  public void acceptUserName() throws IOException {
	  obj2.init_page2(wd);
	  obj2.enter_email();
	  test.log(Status.PASS, "Data entered in email field ");
  }
  
  @Test(priority=6)
  public void acceptPassword() {
	  obj2.enter_password();
	  test.log(Status.PASS, "Data entered in password field ");

  }
  
  @Test(priority=7)
  public void ClickButton() {
	  obj2.click_login();
	  test.log(Status.PASS, "button clicked - Login ");

  }
  
  @Test(priority=8)
  public void CloseBrowserApp() {
	  util1.init_utility(wd);
	  util1.close_browser_instance();
	  test.log(Status.PASS,"App closed successfully !");

  }
  
  @AfterTest
  public void teardown() {
	  ext1.close();
	  ext1.flush();
	  
  }
 
  
  
  
  
}
