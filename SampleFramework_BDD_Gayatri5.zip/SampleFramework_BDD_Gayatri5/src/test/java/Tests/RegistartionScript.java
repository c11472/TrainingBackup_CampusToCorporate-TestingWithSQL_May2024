package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class RegistartionScript {
	WebDriver wd;
	
	@Given("The user is in registration page of awesom")
	public void init1() {
		wd = new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/index.php?route=account/register");
			}
	@When("The user enters the first name")
	public void subtacttestr() {
		wd.findElement(By.id("input-firstname")).sendKeys("gayatrimis1@gmail.com");
	}
	@And("The user clicks on submit")
	public void subtest() {
		wd.findElement(By.xpath("/html/body/div[2]/div/div/form/div/div/input[2]")).click();
		System.out.println("It works !");
			}
	
	@Given("The user is in registration page of awesome")
	public void testuserregs() {
		wd = new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/index.php?route=account/register");
		
		
	}
	
	@When("Enter the lastname")
	public void last() {
     System.out.println("last name enetered");		
	}
	

}
