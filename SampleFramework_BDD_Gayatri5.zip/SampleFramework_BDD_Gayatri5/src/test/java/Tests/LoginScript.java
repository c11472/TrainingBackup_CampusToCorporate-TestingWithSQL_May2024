package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginScript {
	WebDriver wd;
	
	@Given("The user is in login page")
	public void loginpage() {
		wd=new FirefoxDriver();
		wd.get("https://awesomeqa.com/ui/index.php?route=account/login");
		
	}
	@When("the user enters the email , pwd")
	public void comparetest() {
		wd.findElement(By.xpath("//*[@id=\"input-email\"]")).sendKeys("test123");
        
		wd.findElement(By.xpath("//*[@id=\"input-password\"]")).sendKeys("tr6687");
	}
	
}
