package com.LoginPage.automationExercise;

public class LoginPage {

}
