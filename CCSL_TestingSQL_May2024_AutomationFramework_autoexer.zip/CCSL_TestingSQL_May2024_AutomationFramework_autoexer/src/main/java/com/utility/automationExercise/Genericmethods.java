package com.utility.automationExercise;

import org.openqa.selenium.WebDriver;

public class Genericmethods {
	
	WebDriver driver;
	
	public void init_Utility(WebDriver driver) {
		this.driver=driver;
	}
	
	public void Wait_Time() throws InterruptedException {
		
			Thread.sleep(4000);
	
	}

}
