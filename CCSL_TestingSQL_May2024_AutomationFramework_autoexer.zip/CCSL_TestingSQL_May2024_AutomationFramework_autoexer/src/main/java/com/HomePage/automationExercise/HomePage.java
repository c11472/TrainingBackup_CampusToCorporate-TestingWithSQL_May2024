package com.HomePage.automationExercise;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public  class HomePage {
	
	// Declare the driver
	
	WebDriver driver;
	
	// Locators
	By login1 = (By) driver.findElement(By.xpath("(//*[contains(text(),' Signup / Login')])[2]"));
	
	//init
	public void initdriver(WebDriver driver) {
		this.driver = driver;
		
	}
	
	// test automation methods
	
	// invoke the app
	
	public void Invoke_AutomationExercise_App() {
	
		driver.get("https://automationexercise.com/");
		
	}
	
	//click on signup/login
	
	public void Click_SignupLogin() throws Exception {
		Thread.sleep(5000);
		if(driver.findElement(login1).isDisplayed()) {
			driver.findElement(login1).click();
		}
			else {
			System.out.println("Invalid locator");
			
		}
	}
	
	
	

}
