package com.Scripts.automationExercise;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.HomePage.automationExercise.HomePage;
import com.utility.automationExercise.Genericmethods;

public class HomePageAuto {
	  HomePage hmp1 = new HomePage();

	  WebDriver driver = new ChromeDriver();
	  

  @Test(priority=1)
  public void invoke() {
	  hmp1.initdriver(driver);
	  hmp1.Invoke_AutomationExercise_App();
	    }
  
   
}
