package stepsdefinitions;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class scripts_google {
	// WebDriver declaration
	WebDriver wd;
	FileReader fr;
	Properties pr;
	String s;

	@Given("Launching the browser firefox browser and invoke google")

	public void Launch_App() throws IOException {

		System.setProperty("webdriver.gecko.driver", "./Drivers/geckodriver.exe");
		fr = new FileReader("./Testdata/input.properties");
		pr = new Properties();
		pr.load(fr);
		wd = new FirefoxDriver();
		wd.get(pr.getProperty("baseurl"));

	}

	@When("validating the current url and pagetitle of the application")
	public void input_searchstring() {
		wd.findElement(By.name("q")).sendKeys(pr.getProperty("inp"));

	}

	@Then("The user must able to get the search result")
	public void validatedata() {
		System.out.println("The user is able to get the search result");
	}
	
}